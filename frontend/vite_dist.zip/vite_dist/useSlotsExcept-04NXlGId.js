import{l as t}from"./lodash-JOg-xzc_.js";import{K as e,c as u}from"./vue-3cI5HxOT.js";function p(s){const o=e();return u(()=>t.filter(o,(l,r)=>!t.includes(s,r)))}export{p as u};
