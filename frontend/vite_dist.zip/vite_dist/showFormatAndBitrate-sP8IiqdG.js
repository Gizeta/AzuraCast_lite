function n(r){if(!r)return"";const t=[];return r.split(" ").forEach(e=>{t.push(e.toUpperCase())}),t.join(" ")}function p(r,t){return r==="flac"?n(r):t+"kbps "+n(r)}export{p as s};
