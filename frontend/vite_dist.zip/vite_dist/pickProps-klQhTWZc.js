import{l as p}from"./lodash-JOg-xzc_.js";import{V as s}from"./usePlayerStore-u6F7AhrE.js";function a(r,o){return s(r,...p.keys(o))}export{a as p};
