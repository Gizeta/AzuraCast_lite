import{c as t}from"./estoolkit-BB6ueWeH.js";import{r as s,a1 as o}from"./vue-D4iyCNc6.js";function f(e){const r=s(t(o(e)));return{record:r,reset:()=>{r.value=t(o(e))}}}export{f as u};
