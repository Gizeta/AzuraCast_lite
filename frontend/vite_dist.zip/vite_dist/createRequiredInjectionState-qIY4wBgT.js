import{k as i}from"./layout-GY1k92gc.js";function c(e,o){const[n,r]=i(e);return[n,()=>{const t=r();if(!t)throw new Error("Missing injection state!");return t}]}export{c};
