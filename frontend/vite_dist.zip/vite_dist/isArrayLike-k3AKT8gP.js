import{f as t}from"./estoolkit-BB6ueWeH.js";function r(n){return n!=null&&typeof n!="function"&&t(n.length)}export{r as i};
