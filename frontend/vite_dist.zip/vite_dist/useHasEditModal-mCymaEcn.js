function r(e){return{doCreate:()=>{var t;(t=e.value)==null||t.create()},doEdit:t=>{var d;(d=e.value)==null||d.edit(t)}}}export{r as u};
