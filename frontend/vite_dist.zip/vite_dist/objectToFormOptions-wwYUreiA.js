import{l as r}from"./lodash-JOg-xzc_.js";function a(e){return r.map(e,(t,o)=>typeof t=="object"?{label:o,options:r.map(t,(n,p)=>({text:n,value:p}))}:{text:t,value:o})}export{a as o};
