import{u as n}from"./estoolkit-BB6ueWeH.js";function c(t){const o=t?.constructor,r=typeof o=="function"?o.prototype:Object.prototype;return t===r}function e(t){return n(t)}export{c as a,e as i};
