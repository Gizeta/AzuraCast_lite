import{s,u as n}from"./vue-D4iyCNc6.js";const a=r=>s(()=>{const{$dirty:t,$invalid:e}=n(r);return t&&e?"text-danger":""});export{a as u};
