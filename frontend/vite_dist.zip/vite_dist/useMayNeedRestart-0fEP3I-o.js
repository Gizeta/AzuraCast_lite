import{u as t}from"./index-Lu7ZOzsr.js";function n(){const e=t("station-restart");return{needsRestart:()=>{e.emit(!0)},mayNeedRestart:()=>{e.emit(!1)}}}export{n as u};
