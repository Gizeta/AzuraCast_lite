import{b as a,u as s,q as r}from"./useStationQuery-2TUeAy9f.js";function u(){const e=a(),t=s();return{mayNeedRestart:()=>{e.invalidateQueries({queryKey:r([],t)})}}}export{u};
