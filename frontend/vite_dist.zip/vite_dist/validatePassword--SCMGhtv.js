import{c as s}from"./index-iyijpqdN.js";import{z as t}from"./zxcvbn-L3djtDUs.js";function n(o){const r=t(o);return!s.req(o)||r.score>2}export{n as v};
